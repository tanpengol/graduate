﻿#pragma strict

public static var isJSConnected : boolean = false;
public static var isJSExtended : boolean = false;
